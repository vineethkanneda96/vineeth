package com.capgemini.trg.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/userc")
public class UserControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String option=request.getParameter("option");
			String url="";
			if(option.equals("g")) {
				url="views/get_id.jsp";
			}else if(option.equals("u")) {
				url="views/get_update_id.jsp";
			}else if(option.equals("d")) {
				url="views/get_delete_id.jsp";
			}else if(option.equals("a")) {
				url="views/user_reg.jsp";
			}else if(option.equals("s")) {
				url="views/show_all_users.jsp";
			}else {
				url="login.html";
			}
			request.getRequestDispatcher(url).
			forward(request, response);
		}catch(Exception e) {
			request.setAttribute("status", e.getMessage());
			request.getRequestDispatcher("views/status.jsp").
			forward(request, response);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
