package com.capgi.parallelproject.dao;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.exception.CustomerNotFound;

public class CustomerDAOImp implements ICustomerDAO {
	Map<Long, Customer> custList = new HashMap<Long, Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
	@Override
	public boolean createAccount(Customer cus) throws CustomerNotFound{
		
		EntityManager em=factory.createEntityManager();
			try{
				
				em.getTransaction().begin();
				
				em.persist(cus);
				em.getTransaction().commit();
				return em.contains(cus);
			}catch(PersistenceException e) {
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}finally {
				em.close();
			}
	}

	@Override
	public double showBalance(int cid,int pin) throws CustomerNotFound{
		double a=0;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			//entityManager=Persistence.createEntityManagerFactory("ParallelProject").createEntityManager();
			Customer customer=em.find(Customer.class,cid);
			if(customer.getAccountNo()==cid&&customer.getPin()==pin){
			a=customer.getBalance();
			System.out.println("Balance is:"+a);
			}else{
				System.out.println("Please enter Correct pin");
			}
			return a;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public double deposit(Customer c, double amount) throws CustomerNotFound{
		double newBal=0;
		newBal=c.getBalance()+amount;;
		c.setBalance(newBal);
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			em.getTransaction().begin();
			em.merge(c);
			em.getTransaction().commit();			
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		return c.getBalance();
	}

	@Override
	public double withDraw(Customer c, double amount) throws CustomerNotFound{
		if(c.getBalance()>amount){
			
		    EntityManager em=factory.createEntityManager();
		    try{
			em.getTransaction().begin();
			double newBal=0;
			newBal=c.getBalance()-amount;
			c.setBalance(newBal);
			em.merge(c);
			em.getTransaction().commit();	
			return c.getBalance();
		    }catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		    }finally {
			em.close();
		    }
		}
		return c.getBalance();
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,double amount, int acc1, int acc2, int pin1) throws CustomerNotFound{
		// TODO Auto-generated method stub
		boolean flag=false;
		if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			if(b.getAccountNo()==acc2){
				if(c.getBalance()>amount){
					EntityManager em=factory.createEntityManager();
				    try{
					em.getTransaction().begin();
					double bal=c.getBalance();
					bal=bal-amount;
					c.setBalance(bal);
					em.merge(c);
					double bal1=b.getBalance();
					bal1=bal1+amount;
					b.setBalance(bal1);
					em.merge(b);
					em.getTransaction().commit();	
					flag=true;
				    }catch(PersistenceException e) {
					e.printStackTrace();
					//TODO: Log to file
					throw new CustomerNotFound(e.getMessage());
				    }finally {
					em.close();
				    }
				}
			}
		}
		return flag;
	}

	@Override
	public Customer printTransactions(int cid,int pin) throws CustomerNotFound{
		// TODO Auto-generated method stub
			if(transaction.containsKey(cid)){
				Object trns=transaction.get(cid);
				System.out.println("Account number : " + cid +"\n"+ trns + "\n");
			}
		return null;
	}
	
	@Override
	public Customer printTransaction(Customer cid){
		Customer cust=null;
		long acc=cid.getAccountNo();
		StringBuffer sb=new StringBuffer();
		sb=cid.getSb();
		sb.append(cid.getBalance());
		sb.append("Balance: \n ");
		cid.setSb(sb);
		transaction.put(acc,sb);
		for(StringBuffer transaction1:transaction.values()){
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("Transaction");
		}
		return cust;
		
	}

	public boolean validateAccountNumber(int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			Customer customer=em.find(Customer.class,cid);
			if(customer.getAccountNo()==cid){
			flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		
	}
	public boolean validatePin(int pin,int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			Customer customer=em.find(Customer.class,cid);
			if(customer.getPin()==pin){
			flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public Customer displayCustomer(int accNo) {
		// TODO Auto-generated method stub
		Customer custo=null;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			custo=em.find(Customer.class,accNo);
			return custo;
		}
		catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			try {
				throw new CustomerNotFound(e.getMessage());
			} catch (CustomerNotFound e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			em.close();
		}
		return custo;
	}
}