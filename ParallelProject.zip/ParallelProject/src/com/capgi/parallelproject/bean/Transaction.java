package com.capgi.parallelproject.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity
public class Transaction implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Transient
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int slNo;
	private String transaction;
	
	@ManyToOne
	@JoinColumn(name="accountId")
	private Customer customer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getSlNo() {
		return slNo;
	}

	public void setSlNo(int slNo) {
		++slNo;
		this.slNo = slNo;
	}

	public Transaction(int id, String transaction, Customer customer) {
		super();
		this.id = id;
		this.transaction = transaction;
		this.customer = customer;
	}
	public Transaction(){}

	@Override
	public String toString() {
		return transaction;
	}
	
	
}

