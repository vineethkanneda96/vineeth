package com.capgi.parallelproject.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.exception.CustomerNotFound;
import com.capgi.parallelproject.service.CustomerServiceImp;
import com.capgi.parallelproject.service.ICustomerService;
/*Integer accountNo, int pin, String customerFirstName, String customerMiddleName,
String customerLastName, String age, String address, String mobileNo, String accountType, double balance,
String gender, String email, String govtId, String birthdate*/
public class CustomerServiceImpTest extends CustomerServiceImp {

	Customer c=new Customer((int)(Math.random()*100000 + 1111100000L),(int)(Math.random()*9000)+1000,"King","","Kingdom","30","jdfh, sf, jsd, jshfd-600048","9999999999","Savings Account",6000.0,"Male","king@king.com","123456789098","02-06-1995");
	Customer b=new Customer((int)(Math.random()*100000 + 1111100000L),(int)(Math.random()*9000)+1000,"King","","Kingdom","30","JSGDD, SDJHS,","9999999999","Savings Account",5000.0,"Male","king@king.com","123456789098","03-04-1994");
	ICustomerService a=new CustomerServiceImp();
	ICustomerService a1=new CustomerServiceImp();
	
	@Test
	public void testCreateAccount() throws CustomerNotFound {
		boolean b1=a.createAccount(c);
		assertTrue(b1);
	}

	@Test
	public void testShowBalance() throws CustomerNotFound {
		assertEquals(6000.0,c.getBalance(),Math.abs( 6000.0-c.getBalance() ));
		assertEquals(5000.0, b.getBalance(),Math.abs( 5000.0-b.getBalance() ));
	}

	@Test
	public void testDeposit() throws CustomerNotFound {
		double deposit=a.deposit(c, c.getAccountNo(), c.getPin(), 400);
		double deposit1=a1.deposit(b, b.getAccountNo(), b.getPin(), 450);
		assertEquals(400.0,deposit,Math.abs( 400.0-deposit ) );
		assertEquals(450.0, deposit1,Math.abs( 400.0-deposit1 ));
	}

	@Test
	public void testWithDraw() throws CustomerNotFound {
		c.setBalance(400);
		double deposit=a.withDraw(c, c.getAccountNo(), c.getPin(), 450);
		double deposit1=a1.withDraw(b, b.getAccountNo(), b.getPin(), 490);
		assertFalse(c.getBalance()-deposit>500);
		assertEquals(490.0, deposit1,Math.abs( 400.0-deposit1 ));
	}

	@Test
	public void testFundTransfer() throws CustomerNotFound {
		assertTrue(a.fundTransfer(c, b, 500, c.getAccountNo(), b.getAccountNo(), c.getPin()));
		c.setBalance(500);
		assertFalse(a.fundTransfer(c, b, 600, c.getAccountNo(), b.getAccountNo(), c.getPin()));
	}

	@Test
	public void testPrintTransaction() throws CustomerNotFound {
		List<Transaction> list=new ArrayList<Transaction>();
		list.add(new Transaction(1,"hsfjdfkjf",c));
		list.add(new Transaction(2,"hshgrjhrh",c));
		list.add(new Transaction(3,"srlrkekr",c));
		assertEquals("pass", 3, list.size());
	}
}
