package com.capgi.parallelproject.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.exception.CustomerNotFound;
import com.capgi.parallelproject.service.CustomerServiceImp;

public class CustomerServiceImpTest extends CustomerServiceImp {

	Customer c=new Customer(1111189076,7788,"King","","Kingdom","30","jdfh, sf, jsd, jshfd-600048","9999999999","Savings Account",6000.0,"Male","king@king.com","123456789098");
	Customer b=new Customer(1111189078,7788,"King",null,"Kingdom","30",null,"9999999999","Savings Account",6000.0,"Male","king@king.com","123456789098");
	CustomerServiceImp a=new CustomerServiceImp();
	
	@Test
	public void testCreateAccount() throws CustomerNotFound {
		boolean b1=a.createAccount(c);
		assertNotEquals("false", b1);
	}

	@Test
	public void testShowBalance() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testDeposit() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testWithDraw() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testFundTransfer() throws CustomerNotFound {
		double amount=c.getBalance();
		assertNotNull(a.fundTransfer(c, b, amount, c.getAccountNo(), b.getAccountNo(), c.getPin()));
	}

	@Test
	public void testPrintTransaction() {
		assertNotNull(c);
	}

}
