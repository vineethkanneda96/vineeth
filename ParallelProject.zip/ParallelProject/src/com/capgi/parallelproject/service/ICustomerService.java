package com.capgi.parallelproject.service;

import java.util.List;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.exception.CustomerNotFound;

public interface ICustomerService {
	public boolean createAccount(Customer c) throws CustomerNotFound;
	
	public Customer displayCustomer(int accNo);
    
	public double showBalance(int cid, int pin) throws CustomerNotFound;

	public double deposit(Customer c, double amount) throws CustomerNotFound;

	public double withDraw(Customer c, double amount) throws CustomerNotFound;

	public boolean fundTransfer(Customer c,Customer b,double amount, int acc1, int acc2, int pin1) throws CustomerNotFound;

	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFound;
	
}


