package com.capgi.parallelproject.service;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.exception.CustomerNotFound;

public interface ICustomerService {
	public boolean createAccount(Customer c) throws CustomerNotFound;
	
	public Customer displayCustomer(int accNo);
    
	public double showBalance(int cid, int pin) throws CustomerNotFound;

	public double deposit(Customer c, double amount) throws CustomerNotFound;

	public double withDraw(Customer c, double amount) throws CustomerNotFound;

	public boolean fundTransfer(Customer c,Customer b,double amount, int acc1, int acc2, int pin1) throws CustomerNotFound;

	public Customer printTransactions(int cid,int pin) throws CustomerNotFound;
	
	public Customer printTransaction(Customer c);
}


