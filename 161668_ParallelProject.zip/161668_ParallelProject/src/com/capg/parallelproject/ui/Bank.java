package com.capg.parallelproject.ui;

import java.util.Scanner;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.exception.CustomerNotFound;
import com.capg.parallelproject.service.CustomerServiceImp;

public class Bank {

	public static void main(String[] args) {
		CustomerServiceImp service = new CustomerServiceImp();
		while (true) {
			System.out.println("WELCOME TO BANKING SYSTEM");
			System.out.println("ENTER 1 TO CREATE NEW ACCOUNT");
			System.out.println("ENTER 2 TO SHOW BALANCE");
			System.out.println("ENTER 3 FOR DEPOSIT");
			System.out.println("ENTER 4 TO WITHDRAW");
			System.out.println("ENTER 5 FOR FUND TRANSFER");
			System.out.println("ENTER 6 TO PRINT TRANSACTIONS");
			System.out.println("ENTER 7 TO EXIT");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("ENTER CUSTOMER ID");
				int cid = sc.nextInt();
				System.out.println("ENTER CUSTOMER NAME:");
				String cname = sc.next();
				System.out.println("ENTER MOBILE NO:");
				long mobileNo=sc.nextLong();
				System.out.println("ENTER AGE");
				int age = sc.nextInt();
				System.out.println("ENTER CUSTOMER ADDRESS:");
				String addr = sc.nextLine();
				System.out.println("ENTER THE ACCOUNT TYPE:");
				String accType = sc.next();
				Customer bean = new Customer();
				bean.setCid(cid);
				bean.setCname(cname);
				bean.setAddress(addr);
				bean.setAccountType(accType);
				bean.setAge(age);
				bean.setMobileNo(mobileNo);
				boolean isValid = service.validateCreateAccount(bean);
				if (isValid) {
					boolean isAdded = service.createAccount(bean);
					if (isAdded) {
						System.out.println("Record added successfully");
						System.out.println(bean);
					} else {
						System.out.println("Record not added..");
					}
				} else {
					System.err.println("SORRY INVALID DATA PLEASE ENTER CORRECT DATA");
				}

				break;
			case 2:
				System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
				int id = sc.nextInt();
				boolean valid = service.validateShowBalance(id);
				if (valid) {
					Customer c = service.showBalance(id);
					if (c != null) {
						System.out.println(c);
					} else {
						try {
							throw new CustomerNotFound();
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				break;

			case 3:
				break;
			case 7:

				System.exit(0);
				break;

			default:
				break;
			}
		}
	}
}
