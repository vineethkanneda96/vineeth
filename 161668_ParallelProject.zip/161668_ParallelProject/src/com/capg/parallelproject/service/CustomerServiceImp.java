package com.capg.parallelproject.service;

import java.util.regex.Pattern;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.dao.CustomerDAOImp;

public class CustomerServiceImp implements ICustomerService {
     CustomerDAOImp dao=new CustomerDAOImp();
	@Override
	public boolean createAccount(Customer c) {
		// TODO Auto-generated method stub
		return dao.createAccount(c);
	}

	@Override
	public Customer showBalance(int cid) {
		// TODO Auto-generated method stub
		return dao.showBalance(cid);
	}

	@Override
	public boolean deposit(int cid, long amount) {
		// TODO Auto-generated method stub
		return dao.deposit(cid, amount);
	}

	@Override
	public boolean withDraw(int cid, long amount) {
		// TODO Auto-generated method stub
		return dao.withDraw(cid, amount);
	}

	@Override
	public boolean fundTransfer(int sid, int ifsc, String sname, long accountNo) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(sid, ifsc, sname, accountNo);
	}

	@Override
	public boolean printTransactions(int cid) {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid);
	}
    public boolean validateCreateAccount(Customer c){
		
		// use regular expressions or our own user defined validations
		boolean flag=false;
		if(c.getCid()>99 && c.getCname().length()>=4 && c.getAge()>18){
			
			flag=true;
			
		}
		
		/*Pattern id =Pattern.compile("[0-9]");
		Pattern name=Pattern.compile("[A-Z][a-zA-Z]");
		Pattern age=Pattern.compile("[0-9]");
		Pattern address=Pattern.compile("[A-Za-z]");
		Pattern accountType=Pattern.compile("[A-Za-z]");*/
		return flag;
    	
    		
    		
    		
    	
	}
	
	public boolean validateShowBalance(int cid){
		boolean flag=false;
		if(cid>99){
			flag =true;
		}
		return flag;
	}
	public boolean validateDeposit(int cid, long amount){
		return false;
	}
	public boolean validateWithDraw(int cid, long amount) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean validateFundTransfer(int sid, int ifsc, String sname, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean validatePrintTransactions(int cid) {
		// TODO Auto-generated method stub
		return false;
	}
}
