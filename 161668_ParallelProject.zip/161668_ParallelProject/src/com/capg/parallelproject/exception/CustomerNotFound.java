package com.capg.parallelproject.exception;

public class CustomerNotFound extends Exception {

}
