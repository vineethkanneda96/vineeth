package com.capg.parallelproject.dao;

import com.capg.parallelproject.bean.Customer;

public interface ICustomerDAO {
	public boolean createAccount(Customer c);

	public Customer showBalance(int cid);

	public boolean deposit(int cid, long amount);

	public boolean withDraw(int cid, long amount);

	public boolean fundTransfer(int sid, int ifsc, String sname, long accountNo);

	public boolean printTransactions(int cid);
}
