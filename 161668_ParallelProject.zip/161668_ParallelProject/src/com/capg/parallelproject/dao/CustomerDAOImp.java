package com.capg.parallelproject.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.parallelproject.bean.Customer;

public class CustomerDAOImp implements ICustomerDAO {
	static List<Customer> custList = new ArrayList<Customer>();
	@Override
	public boolean createAccount(Customer c) {
		// TODO Auto-generated method stub
		return custList.add(c);
	}

	@Override
	public Customer showBalance(int cid) {
		// TODO Auto-generated method stub
		Customer cust = null;
		for (Customer c : custList) {
			if (c.getCid() == cid) {
				cust = c;
			}

		}
		return cust;
	}

	@Override
	public boolean deposit(int cid, long amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withDraw(int cid, long amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundTransfer(int sid, int ifsc, String sname, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printTransactions(int cid) {
		// TODO Auto-generated method stub
		return false;
	}

}
