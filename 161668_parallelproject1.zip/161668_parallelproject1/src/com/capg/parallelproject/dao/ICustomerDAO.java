package com.capg.parallelproject.dao;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.exception.CustomerNotFound;

public interface ICustomerDAO {
	public boolean createAccount(Customer c) throws CustomerNotFound;
	
	public Customer displayCustomer(long accNo);

	public long showBalance(long cid, int pin) throws CustomerNotFound;

	public long deposit(Customer c, long amount) throws CustomerNotFound;

	public long withDraw(Customer c, long amount) throws CustomerNotFound;

	public boolean fundTransfer(Customer c,Customer b,long amount, long acc1, long acc2, int pin1) throws CustomerNotFound;
	
	public Customer printTransaction(Customer c);

	public Customer printTransactions(long cid,int pin) throws CustomerNotFound;
}
