package com.capg.parallelproject.utility;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JPAUtil {

	public static EntityManager getEntityManager() {
	
		return Persistence.createEntityManagerFactory("161668_parallelproject").createEntityManager();
	}
}
