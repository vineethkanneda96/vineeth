package com.capg.parallelproject.service;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.exception.CustomerNotFound;

public interface ICustomerService {
	public boolean createAccount(Customer c) throws CustomerNotFound;
	
	public Customer displayCustomer(long accNo);
    
	public long showBalance(long cid, int pin) throws CustomerNotFound;

	public long deposit(Customer c, long amount);

	public long withDraw(Customer c, long amount);

	public boolean fundTransfer(Customer c,Customer b,long amount, long acc1, long acc2, int pin1);

	public Customer printTransactions(long cid,int pin);
	
	public Customer printTransaction(Customer c);
}

