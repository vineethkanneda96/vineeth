package com.capg.parallelproject.dao;

import com.capg.parallelproject.bean.Customer;

public interface ICustomerDAO {
	public boolean createAccount(Customer c);
	
	public Customer displayCustomer(long accNo);

	public double showBalance(long cid, int pin);

	public double deposit(Customer c, double amount);

	public double withDraw(Customer c, double amount);

	public boolean fundTransfer(Customer c,Customer b,double amount, long acc1, long acc2, int pin1);
	
	public Customer printTransaction(Customer c);

	public Customer printTransactions(long cid,int pin);
}
