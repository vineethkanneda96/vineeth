package com.capg.parallelproject.dao;

import com.capg.parallelproject.bean.Customer;

public interface ICustomerDAO {
	public boolean createAccount(Customer c);
	
	public Customer displayCustomer(long accNo);

	public long showBalance(long cid, int pin);

	public long deposit(Customer c, long amount);

	public long withDraw(Customer c, long amount);

	public boolean fundTransfer(Customer c,Customer b,long amount, long acc1, long acc2, int pin1);
	
	public Customer printTransaction(Customer c);

	public Customer printTransactions(long cid,int pin);
}
