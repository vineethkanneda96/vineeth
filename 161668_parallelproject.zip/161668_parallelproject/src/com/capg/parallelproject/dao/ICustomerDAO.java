package com.capg.parallelproject.dao;

import com.capg.parallelproject.bean.Customer;

public interface ICustomerDAO {
	public boolean createAccount(Customer c);
	
	public Customer displayCustomer(int accNo);

	public long showBalance(int cid, int pin);

	public long deposit(Customer c, long amount);

	public long withDraw(Customer c, long amount);

	public boolean fundTransfer(Customer c,Customer b,long amount, int acc1, int acc2, int pin1);
	
	public Customer printTransaction(Customer c);

	public Customer printTransactions(int cid,int pin);
}
