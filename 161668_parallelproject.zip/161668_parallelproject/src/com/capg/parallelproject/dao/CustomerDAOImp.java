package com.capg.parallelproject.dao;

import java.util.HashMap;
import java.util.Map;
import com.capg.parallelproject.bean.Customer;

public class CustomerDAOImp implements ICustomerDAO {
	Map<Long, Customer> custList = new HashMap<Long, Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	@Override
	public boolean createAccount(Customer cus) {
		// TODO Auto-generated method stub
		long key=cus.getAccountNo();
		custList.put(key, cus);
		 return custList.containsValue(cus);
	}

	@Override
	public double showBalance(long cid,int pin) {
		// TODO Auto-generated method stub
		double a=0;
		for (Customer c : custList.values()) {
			if ((c.getAccountNo()==cid)&&(c.getPin()==pin)) {
				a=c.getBalance();
				System.out.println("Balance is:"+a);
				
			}
		}
		return a;
	}

	@Override
	public double deposit(Customer c, double amount){
		// TODO Auto-generated method stub
	/*	System.out.println("Successfully Deposited");
		System.out.println("Updated Balance="+c.getBalance());*/
		return c.getBalance();
	}

	@Override
	public double withDraw(Customer c, double amount){
		// TODO Auto-generated method stub
		/*System.out.println("WithDraw Successful");
		System.out.println("Updated Balance="+c.getBalance());*/
		return c.getBalance();
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,double amount, long acc1, long acc2, int pin1){
		// TODO Auto-generated method stub
		boolean flag=false;
		if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			if(b.getAccountNo()==acc2){
				if(c.getBalance()>amount){
					flag=true;
				}
			}
		}
		return flag;
	}

	@Override
	public Customer printTransactions(long cid,int pin) {
		// TODO Auto-generated method stub
			if(transaction.containsKey(cid)){
				Object trns=transaction.get(cid);
				System.out.println("Account number : " + cid +"\n"+ trns + "\n");
			}
		return null;
	}
	
	@Override
	public Customer printTransaction(Customer cid){
		Customer cust=null;
		long acc=cid.getAccountNo();
		StringBuffer sb=new StringBuffer();
		sb=cid.getSb();
		sb.append(cid.getBalance());
		sb.append("Balance: \n ");
		cid.setSb(sb);
		transaction.put(acc,sb);
		for(StringBuffer transaction1:transaction.values()){
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("Transaction");
		}
		return cust;
		
	}

	public boolean validateAccountNumber(long cid) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for (Customer c : custList.values()) {
			if (c.getAccountNo()==cid) {
				flag=true;;
			}
			
		}
		return flag;
	}
	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for (Customer c : custList.values()) {
			if (c.getPin()==pin) {
			flag=true;
			}
		}
		return flag;
	}

	@Override
	public Customer displayCustomer(long accNo) {
		// TODO Auto-generated method stub
		Customer custo=null;
		for (Customer c : custList.values()) {
			if ((c.getAccountNo()==accNo) ){
				custo=c;
			}
		}
		return custo;
	}

}