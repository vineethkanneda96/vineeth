package com.capg.parallelproject.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capg.parallelproject.bean.Customer;

public class CustomerDAOImp implements ICustomerDAO {
	Map<Integer, Customer> custList = new HashMap<Integer, Customer>();
	Map<Integer, StringBuffer> transaction = new HashMap<Integer, StringBuffer>();
	@Override
	public boolean createAccount(Customer cus) {
		// TODO Auto-generated method stub
		int key=cus.getAccountNo();
		custList.put(key, cus);
		 return custList.containsValue(cus);
	}

	@Override
	public Customer showBalance(int cid,int pin) {
		// TODO Auto-generated method stub
		Customer custo=null;
		for (Customer c : custList.values()) {
			if ((c.getAccountNo()==cid)&&(c.getPin()==pin)) {
				System.out.println("Balance is:"+c.getBalance());
			}
		}
		return custo;
	}

	@Override
	public long deposit(Customer c, long amount){
		// TODO Auto-generated method stub
	/*	System.out.println("Successfully Deposited");
		System.out.println("Updated Balance="+c.getBalance());*/
		return c.getBalance();
	}

	@Override
	public long withDraw(Customer c, long amount){
		// TODO Auto-generated method stub
		/*System.out.println("WithDraw Successful");
		System.out.println("Updated Balance="+c.getBalance());*/
		return c.getBalance();
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,long amount, int acc1, int acc2, int pin1){
		// TODO Auto-generated method stub
		boolean flag=false;
		if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			if(b.getAccountNo()==acc2){
				if(c.getBalance()>amount){
					long bal=0;
					long bal1=0;
					bal=c.getBalance()-amount;
					bal1=b.getBalance()+amount;
					c.setBalance(bal);
					b.setBalance(bal1);
				}
			}
		}
		return flag;
	}

	@Override
	public Customer printTransactions(int cid,int pin) {
		// TODO Auto-generated method stub
		for (StringBuffer trns : transaction.values()) {
			if(transaction.containsKey(cid)){
				System.out.println(transaction.values());
			}
		}
		return null;
	}
	public Customer printTransaction(Customer cid){
		Customer cust=null;
		int acc=cid.getAccountNo();
		StringBuffer sb=new StringBuffer();
		sb=cid.getSb();
		sb.append(cid.getBalance());
		cid.setSb(sb);
		transaction.put(acc,sb);
		for(StringBuffer transaction1:transaction.values()){
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("Transaction");
		}
		return cust;
		
	}

	public boolean validateAccountNumber(int cid) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for (Customer c : custList.values()) {
			if (c.getAccountNo()==cid) {
				flag=true;;
			}
			
		}
		return flag;
	}
	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for (Customer c : custList.values()) {
			if (c.getPin()==pin) {
			flag=true;
			}
		}
		return flag;
	}

	@Override
	public Customer displayCustomer(int accNo) {
		// TODO Auto-generated method stub
		Customer custo=null;
		for (Customer c : custList.values()) {
			if ((c.getAccountNo()==accNo) ){
				custo=c;
			}
		}
		return custo;
	}

}