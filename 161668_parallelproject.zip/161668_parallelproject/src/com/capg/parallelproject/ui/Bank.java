package com.capg.parallelproject.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.bean.Customer.Gender;
import com.capg.parallelproject.exception.CustomerNotFound;
import com.capg.parallelproject.service.CustomerServiceImp;

public class Bank {

	long amount;
	public static void main(String[] args) throws CustomerNotFound,IOException {
		CustomerServiceImp service = new CustomerServiceImp();
		//Customer bean=new Customer(null, null, null, 0, null, null, null);
		System.out.println("***********************:");
	while (true) {
			System.out.println("*************************************************");
			System.out.println("-------------------------------------------------");
			System.out.println("WELCOME TO BANKING SYSTEM");
			System.out.println("-------------------------------------------------");
			System.out.println("*************************************************");
			System.out.println("ENTER 1 TO CREATE NEW ACCOUNT");
			System.out.println("ENTER 2 TO SHOW BALANCE");
			System.out.println("ENTER 3 FOR DEPOSIT");
			System.out.println("ENTER 4 TO WITHDRAW");
			System.out.println("ENTER 5 FOR FUND TRANSFER");
			System.out.println("ENTER 6 TO PRINT TRANSACTIONS");
			System.out.println("ENTER 7 TO EXIT");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			Customer bean=new Customer(null, null, null, 0, null, null, null);
			switch (choice) {
			
			case 1:
				
				/*boolean valid=false;
				do {
			       
					BufferedReader customerFirstName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					    //System.out.println("***********************:");
						
						
						try {
							System.out.println("ENTER CUSTOMER FIRSTNAME:");
							n=customerFirstName.readLine();
							String s=service.toTitleCase(n);
							bean.setCustomerFirstName(s);
							valid=service.validateCustomerFirstName(s);
							if(valid){
								break;
							}else{
								System.err.println("Please enter valid name. Name should contain atleast 2 letters");
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						
					bean.setCustomerFirstName(n);
					valid=service.validateCustomerFirstName(n,bean);
					if(valid){
						continue;
					}else{
						System.out.println("Please enter valid name. Name should contain atleast 3 letters");
					}
					
				} while (!valid);
				boolean valid1=false;
				do {
			        StringBuffer customerFirstName = new StringBuffer();
					char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}
					BufferedReader customerMiddleName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER MIDDLENAME:");
						n=customerMiddleName.readLine();
						//String s=service.toTitleCase(n);
						bean.setCustomerMiddleName(n);
						valid1=service.validateCustomerMiddleName(n);
						if(valid1){
							break;
						}else{
							System.err.println("Please enter valid name.");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				} while (!valid1);
				boolean valid2=false;
				do {
			        StringBuffer customerFirstName = new StringBuffer();
					char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}
					BufferedReader customerLastName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER LASTNAME:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=customerLastName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerLastName(s);
						valid2=service.validateCustomerLastName(s);
						if(valid2){
							break;
						}else{
							System.err.println("Please enter valid name. Name should contain atleast 2 letters");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				} while (!valid2);*/
				boolean valid3=false;
				do{
				System.out.println("ENTER MOBILE NO:");
				StringBuffer mobileNo=new StringBuffer();
				StringBuffer mobileNo1=new StringBuffer("+(0/91)-");
				StringBuffer mobileNo2=new StringBuffer();
				mobileNo2.append(sc.next());
				mobileNo=mobileNo1.append(mobileNo2);
				bean.setMobileNo(mobileNo2);
				valid3=service.validateMobileNo(mobileNo2,bean);
				if(valid3){
					bean.setMobileNo(mobileNo);
					break;
				}else{
					System.err.println("Please enter valid mobile number. It should be 10digits");
				}
				}while(!valid3);
				boolean valid4=false;
				do{
				System.out.println("ENTER AGE");
				int age = sc.nextInt();
				bean.setAge(age);
				valid4=service.validateAge(age);
				if(valid4){
					break;
				}else{
					System.err.println("Please enter valid age. Age is a number between 0 and 100");
				}
				}while(!valid4);
				int valid5=0;
				do{
				System.out.println("ENTER GENDER");
				String gender=sc.next().toUpperCase();
				valid5=service.validateGender(gender);
				if(valid5==1){
				    Gender a=Gender.Male;
					bean.setGender(a);
				}else if(valid5==2){
					Gender b=Gender.Female;
					bean.setGender(b);
				}else{
					System.err.println("Please enter valid gender. Please select  M for Male or F for Female");
				}
				}while(valid5==0);
				boolean valid6=false;
				do{
				System.out.println("ENTER EMAIL-ADDRESS:");
				String email=sc.next();
				valid6=service.validateEmailAddress(email);
				if(valid6){
				  bean.setEmail(email);
				}else{
					System.err.println("Please enter valid email address");
				}
				}while(!valid6);
				int valid7=0;
				do{
				System.out.println("ENTER A GOVERNMENT ID DETAILS:");
				System.out.println("ENTER 1 FOR PANCARD");
				System.out.println("ENTER 2 FOR AADHAR");
				System.out.println("ENTER 3 FOR VOTERID");
				System.out.println("ENTER 4 FOR DRIVING LICENSE:");
				int choice1=sc.nextInt();
				if(choice1==1){
					System.out.println("ENTER PANCARD NO.");
					String panNo=sc.next().toUpperCase();
					valid7=service.validatePanNo(panNo);
					if(valid7==1){
						bean.setGovtId(panNo);
					}else{
						System.err.println("Please enter valid pan no.");
					}
				}
				
				else if(choice1==2){
					System.out.println("ENTER AADHAR NO.:");
					String aadharNo=sc.next();
					valid7=service.validateAadharNo(aadharNo);
					if(valid7==1){
						bean.setGovtId(aadharNo);
					}else{
						System.err.println("Please enter valid Aadhar no.");
					}
				}
				
				else if(choice1==3){
					System.out.println("ENTER VOTER ID NO.:");
					String voterId=sc.next().toUpperCase();
					valid7=service.validateVoterId(voterId);
					if(valid7==1){
						bean.setGovtId(voterId);
					}else{
						System.err.println("Please enter valid Voter id no.");
					}
				}
				else if(choice1==4){
					System.out.println("ENTER DRIVING LICENSE NO.:");
					String drivingLicenseNo=sc.next();
					valid7=service.validatedrivingLicenseNo(drivingLicenseNo);
					if(valid7==1){
						bean.setGovtId(drivingLicenseNo);
					}else{
						System.err.println("Please enter valid Driving License No.");
					}
				}
				else{
					System.err.println("Please enter valid choice");
				}
				}while(valid7==0);
				boolean valid8=false;
				do{
					System.out.println("ENTER CUSTOMER ADDRESS:");
					StringBuffer address=new StringBuffer();;
					StringBuffer address1=new StringBuffer();
					StringBuffer address2=new StringBuffer();
					StringBuffer address3=new StringBuffer();
					StringBuffer address4=new StringBuffer();
					Integer address5;
					System.out.println("H.No./Flat No.");
					address1.append(sc.next());
					System.out.println("Street Name/Colony Name/Area");
					address2.append(sc.next());
					System.out.println("City");
					address3.append(sc.next());
					System.out.println("State");
					address4.append(sc.next());
					System.out.println("Pincode");
					address5=sc.nextInt();
					boolean valid9=service.validatePinCode(address5);
					if(valid9){
					address=address1.append(", "+address2).append(", "+address3).append(", "+address4).append(" -"+address5);
					bean.setAddress(address);
					valid8=service.validateAddress(address,bean);
				    if(valid8){
					    break;
				    }else{
					System.err.println("Please enter valid address");
				   }
				}else{
					   System.err.println("Please enter valid Pincode. Pincode is a 6digit Number");
				   }
				}while(!valid8);
				boolean valid10=false;
				do {
			        //StringBuffer customerFirstName = new StringBuffer();
					/*char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}*/
					BufferedReader accountType= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER THE ACCOUNT TYPE:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=accountType.readLine();
						bean.setAccountType(n);
						valid10=service.validateCustomerFirstName(n);
						if(valid10){
							break;
						}else{
							System.err.println("Please enter valid Account Type");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (!valid10);
					boolean isAdded = service.createAccount(bean);
					if (isAdded) {
						long Balance=0;
						System.out.println("Record added successfully");
						System.out.println(bean);
						System.out.println("ENTER OPENING BALANCE:");
						System.out.println("Amount should be in numbers EX:1000,2000,3000");
						Balance=sc.nextLong();
						boolean valid12=service.validateOpeningBalance(Balance);
						if(valid12){
						bean.setBalance(Balance);
						
						System.out.println("Your AccountNo:"+bean.getAccountNo()+" Balance:"+bean.getBalance());
						}else{
							System.err.println("Please enter valid amount");
						}
					} else {
						System.err.println("Record not added..");
					}
				break;
			case 2:
				boolean isvalidacc=false,isvalidpin=false;
				do{
				System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
				int cid = sc.nextInt();
				isvalidacc=service.validateAccountNumber(cid);
				if(isvalidacc){
				System.out.println("ENTER YOUR PIN");
				int pin=sc.nextInt();
				isvalidpin=service.validatePin(pin);
				if(isvalidpin){
					Customer c =service.displayCustomer(cid);
					if(c.getAccountNo()==cid&&c.getPin()==pin){
						service.showBalance(cid, pin);
					}else {
						System.err.println("Please enter correct pin");
					}
					
				}else {
					System.err.println("Please enter correct pin");
				}
				}
				//System.out.println(c.getBalance());
				
					/*if (c) {
						Customer c1=service.showBalance(cid, pin);
						System.out.println(c1.getOpeningBalance());
					}else{
						System.out.println("PLEASE ENTER CORRECT PIN");
					} 
				}*/
					else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}while(!isvalidacc||!isvalidpin);
			break;

			case 3:
				boolean isvalid=false,isvalid1=false;
				do{
				System.out.println("Enter Account No.");
			    int acc1=sc.nextInt();
			    isvalid=service.validateAccountNumber(acc1);
			    if(isvalid){
			    		System.out.println("Enter pin:");
			    		int pin1=sc.nextInt();
			    		isvalid1=service.validatePin(pin1);
			    		if(isvalid1){
			    			Customer c=service.displayCustomer(acc1);
			    			if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			    			System.out.println("Enter deposit amount");
			    			long deposit=sc.nextLong();
			    			long b=c.getBalance();
			    			long a=service.deposit(c, deposit);
			    			service.printTransaction(c);
			    			if(a>b){
			    				System.out.println("Successfully Deposited....");
			    				System.out.println("Updated Balance:"+a);
			    			}else {
								System.err.println("Deposition Failed");
							}
			    		}else {
							System.err.println("Please enter correct pin");
						}
			    }else {
					System.err.println("Please enter valid pin");
				}
			    }
			    		else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				}while(!isvalid||!isvalid1);
				break;
			case 4:
				boolean isvalid2=false,isvalid3=false;
				do{
				System.out.println("Enter Account No.");
			    int acc2=sc.nextInt();
			    isvalid2=service.validateAccountNumber(acc2);
			    if(isvalid2){
			    		System.out.println("Enter pin:");
			    		int pin2=sc.nextInt();
			    		isvalid3=service.validatePin(pin2);
			    		if(isvalid3){
			    			Customer c=service.displayCustomer(acc2);
			    			if(c.getAccountNo()==acc2&&c.getPin()==pin2){
			    			System.out.println("Enter withdraw amount");
			    			long withdraw=sc.nextLong();
			    			long b=c.getBalance();
			    			long a=service.withDraw(c, withdraw);
			    			service.printTransaction(c);
			    			if(a<b){
			    				System.out.println("Successfully WithDrawn");
			    				System.out.println("Updated Balance:"+a);
			    			}else {
								System.err.println("Sorry Insufficient Balance");
							}
			    		}else {
							System.err.println("Please enter correct pin");
						}
			    }else {
					System.err.println("Please enter valid pin");
				}
			    }
			    		else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				}while(!isvalid2||!isvalid3);
				break;
			case 5:
				boolean isvalid4=false,isvalid5=false,isvalid6=false,isvalid9=false;
				do{
				System.out.println("Enter Account No.");
			    int acc3=sc.nextInt();
			    isvalid4=service.validateAccountNumber(acc3);
			    if(isvalid4){
			    	    Customer cust3=service.displayCustomer(acc3);
			    		System.out.println("Enter pin:");
			    		int pin3=sc.nextInt();
			    		isvalid5=service.validatePin(pin3);
			    		if(isvalid5){
			    		if(cust3.getAccountNo()==acc3&&cust3.getPin()==pin3){
			    			System.out.println("Enter the Account Number to transfer:");
			    			int acc4=sc.nextInt();
			    			isvalid6=service.validateAccountNumber(acc4);
			    			if(isvalid6){
			    			System.out.println("Enter Name of the Receiver:");
			    			String sName=sc.next();
			    			System.out.println("Enter IFSC Code");
			    			int ifsc=sc.nextInt();
			    			System.out.println("Enter amount of transfer:");
			    			long deposit=sc.nextLong();
			    			Customer cust4=service.displayCustomer(acc4);
			    			isvalid9=service.fundTransfer(cust3, cust4, deposit, acc3, acc4, pin3);
			    			if(isvalid9){
			    			service.printTransaction(cust3);
			    			service.printTransaction(cust4);
			    			System.out.println("Transaction Successful");
			    			System.out.println("Account No:"+acc3+"Amount after deduction:"+cust3.getBalance());
			    			System.out.println("Account No:"+acc4+"Amount after Credit:"+cust4.getBalance());
			    			}else {
								System.err.println("Insufficient Balance:");
							}
			    		}else {
							System.err.println("Please enter valid Account No.");
						}
			    }else {
					System.err.println("Please enter valid pin");
				}
			    }else {
					System.err.println("Please enter valid pin");
				}
			    }else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				}
			    }while(!isvalid4||!isvalid5||!isvalid6);
				break;
			case 6:
				boolean isvalid7=false,isvalid8=false;
				do{
				System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
				int cid = sc.nextInt();
				isvalid7=service.validateAccountNumber(cid);
				if(isvalid7){
				System.out.println("ENTER YOUR PIN");
				int pin=sc.nextInt();
				isvalid8=service.validatePin(pin);
				if(isvalid8){
					Customer c =service.displayCustomer(cid);
					if(c.getAccountNo()==cid&&c.getPin()==pin){
						service.printTransactions(cid, pin);
					}else {
						System.err.println("Please enter correct pin");
					}
					
				}else {
					System.err.println("Please enter valid pin");
				}
				}
				else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				}while(!isvalid7||!isvalid8);
			break;
			case 7:
                 sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}
}
