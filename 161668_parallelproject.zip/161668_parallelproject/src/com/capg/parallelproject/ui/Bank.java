package com.capg.parallelproject.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.exception.CustomerNotFound;
import com.capg.parallelproject.service.CustomerServiceImp;

public class Bank {

	public static void main(String[] args) throws CustomerNotFound {
		CustomerServiceImp service = new CustomerServiceImp();
		//Customer bean=new Customer(null, null, null, 0, null, null, null);
		while (true) {
			System.out.println("*************************************************");
			System.out.println("-------------------------------------------------");
			System.out.println("WELCOME TO BANKING SYSTEM");
			System.out.println("-------------------------------------------------");
			System.out.println("*************************************************");
			System.out.println("ENTER 1 TO CREATE NEW ACCOUNT");
			System.out.println("ENTER 2 TO SHOW BALANCE");
			System.out.println("ENTER 3 FOR DEPOSIT");
			System.out.println("ENTER 4 TO WITHDRAW");
			System.out.println("ENTER 5 FOR FUND TRANSFER");
			System.out.println("ENTER 6 TO PRINT TRANSACTIONS");
			System.out.println("ENTER 7 TO EXIT");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			//Customer bean=new Customer(null, null, null, 0, null, null, null);
			switch (choice) {
			case 1:
				Customer bean=new Customer(null, null, null, 0, null, null, null);
				boolean valid=false;
				do {
			        /*StringBuffer customerFirstName = new StringBuffer();
					char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}*/
					BufferedReader customerFirstName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER FIRSTNAME:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=customerFirstName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerFirstName(s);
						valid=service.validateCustomerFirstName(s,bean);
						if(valid){
							break;
						}else{
							System.err.println("Please enter valid name. Name should contain atleast 2 letters");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					/*bean.setCustomerFirstName(n);
					valid=service.validateCustomerFirstName(n,bean);*/
					/*if(valid){
						continue;
					}else{
						System.out.println("Please enter valid name. Name should contain atleast 3 letters");
					}*/
					
				} while (!valid);
				boolean valid1=false;
				do {
			        //StringBuffer customerFirstName = new StringBuffer();
					/*char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}*/
					BufferedReader customerMiddleName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER MIDDLENAME:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=customerMiddleName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerFirstName(s);
						valid=service.validateCustomerMiddleName(s,bean);
						if(valid){
							continue;
						}else{break;}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}while(!valid1);
				boolean valid2=false;
				do {
			        //StringBuffer customerFirstName = new StringBuffer();
					/*char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}*/
					BufferedReader customerLastName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER LASTNAME:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=customerLastName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerFirstName(s);
						valid=service.validateCustomerLastName(s,bean);
						if(valid){
							break;
						}else{
							System.out.println("Please enter valid name");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					/*bean.setCustomerFirstName(n);
					valid=service.validateCustomerFirstName(n,bean);*/
					/*if(valid){
						continue;
					}else{
						System.out.println("Please enter valid name. Name should contain atleast 3 letters");
					}*/
					
				} while (!valid2);
				boolean valid3=false;
				do{
				System.out.println("ENTER MOBILE NO:");
				StringBuffer mobileNo=new StringBuffer();
				StringBuffer mobileNo1=new StringBuffer("+(0/91)-");
				StringBuffer mobileNo2=new StringBuffer();
				mobileNo2.append(sc.next());
				mobileNo=mobileNo1.append(mobileNo2);
				bean.setMobileNo(mobileNo2);
				valid3=service.validateMobileNo(mobileNo2,bean);
				if(valid3){
					bean.setMobileNo(mobileNo);
					break;
				}else{
					System.out.println("Please enter valid mobile number. It should be 10digits");
				}
				}while(!valid3);
				boolean valid4=false;
				do{
				System.out.println("ENTER AGE");
				int age = sc.nextInt();
				bean.setAge(age);
				valid4=service.validateAge(age,bean);
				if(valid4){
					break;
				}else{
					System.out.println("Please enter valid age. Age is a number between 0 and 100");
				}
				}while(!valid4);
				boolean valid5=false;
				do{
					System.out.println("ENTER CUSTOMER ADDRESS:");
					StringBuffer address=new StringBuffer();;
					StringBuffer address1=new StringBuffer();
					StringBuffer address2=new StringBuffer();
					StringBuffer address3=new StringBuffer();
					StringBuffer address4=new StringBuffer();
					Integer address5;
					System.out.println("H.No./Flat No.");
					address1.append(sc.next());
					System.out.println("Street Name/Colony Name/Area");
					address2.append(sc.next());
					System.out.println("City");
					address3.append(sc.next());
					System.out.println("State");
					address4.append(sc.next());
					System.out.println("Pincode");
					address5=sc.nextInt();
					boolean valid6=service.validatePinCode(address5);
					if(valid6){
					address=address1.append(", "+address2).append(", "+address3).append(", "+address4).append(" -"+address5);
					bean.setAddress(address);
					valid5=service.validateAddress(address,bean);
				    if(valid5){
					    break;
				    }else{
					System.out.println("Please enter valid address");
				   }
				}else{
					   System.out.println("Please enter valid Pincode. Pincode is a 6digit Number");
				   }
				}while(!valid5);
				boolean valid7=false;
				do {
			        //StringBuffer customerFirstName = new StringBuffer();
					/*char c;
					System.out.println("ENTER CUSTOMER FIRSTNAME:");
					try {
						while ((c = (char) System.in.read()) != '\n') {
							customerFirstName.append(c);
						}
					} catch (Exception e) {
					}*/
					BufferedReader accountType= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER THE ACCOUNT TYPE:");
						//while(!(s=br.readLine().equals("exit")){System.out.print(s);}  should be done if we want to enter multiple words untill user exits it
						n=accountType.readLine();
						bean.setAccountType(n);
						valid=service.validateCustomerFirstName(n,bean);
						if(valid){
							break;
						}else{
							System.out.println("Please enter valid Account Type");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					/*bean.setCustomerFirstName(n);
					valid=service.validateCustomerFirstName(n,bean);*/
					/*if(valid){
						continue;
					}else{
						System.out.println("Please enter valid name. Name should contain atleast 3 letters");
					}*/
					
				} while (!valid7);
				/*bean.setCname(cname);
				bean.setAddress(addr);
				bean.setAccountType(accType);
				bean.setAge(age);
				bean.setMobileNo(mobileNo);*/
				//bean.getCid();
				/*boolean isValid = service.validateCreateAccount(bean);
				if (isValid) {*/
					boolean isAdded = service.createAccount(bean);
					if (isAdded) {
						long Balance=0;
						System.out.println("Record added successfully");
						System.out.println(bean);
						System.out.println("ENTER OPENING BALANCE:");
						System.out.println("Amount should be in numbers EX:1000,2000,3000");
						Balance=sc.nextLong();
						boolean valid12=service.validateOpeningBalance(Balance);
						if(valid12){
						bean.setBalance(Balance);
						
						System.out.println("Your AccountNo:"+bean.getAccountNo()+" Balance:"+bean.getBalance());
						}else{
							System.out.println("Please enter valid amount");
						}
					} else {
						System.out.println("Record not added..");
					}
				/*else {
					System.err.println("SORRY INVALID DATA PLEASE ENTER CORRECT DATA");
				}*/

				break;
			case 2:
				System.out.println("ENTER ACCOUNT ID TO GET THE BALANCE");
				int cid = sc.nextInt();
				boolean isvalidacc=service.validateAccountNumber(cid);
				if(isvalidacc){
				System.out.println("ENTER YOUR PIN");
				int pin=sc.nextInt();
				boolean isvalidpin=service.validatePin(pin);
				if(isvalidpin){
					Customer c =service.displayCustomer(cid);
					if(c.getAccountNo()==cid&&c.getPin()==pin){
						service.showBalance(cid, pin);
					}else{
						System.out.println("Please enter correct pin");
					}
					
				}else{
					System.out.println("Sorry Invalid Pin");
					}
				}
				//System.out.println(c.getBalance());
				
					/*if (c) {
						Customer c1=service.showBalance(cid, pin);
						System.out.println(c1.getOpeningBalance());
					}else{
						System.out.println("PLEASE ENTER CORRECT PIN");
					} 
				}*/
					else {
						try {
							throw new CustomerNotFound("Please enter a valid Account Number");
						} catch (CustomerNotFound e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				
			break;

			case 3:
				System.out.println("Enter Account No.");
			    int acc1=sc.nextInt();
			    boolean isvalid=service.validateAccountNumber(acc1);
			    if(isvalid){
			    		System.out.println("Enter pin:");
			    		int pin1=sc.nextInt();
			    		boolean isvalid1=service.validatePin(pin1);
			    		if(isvalid1){
			    			System.out.println("Enter deposit amount");
			    			long deposit=sc.nextLong();
			    			Customer c=service.displayCustomer(acc1);
			    			long b=c.getBalance();
			    			long a=service.deposit(c, deposit);
			    			service.printTransaction(c);
			    			if(a>b){
			    				System.out.println("Successfully Deposited");
			    				System.out.println("Updated Balance:"+a);
			    			}else{
			    				System.out.println("Deposition failed");
			    			}
			    		}else{
			    			System.out.println("Please enter correct pin");
			    		}
			    }else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				break;
			case 4:
				System.out.println("Enter Account No.");
			    int acc2=sc.nextInt();
			    boolean isvalid1=service.validateAccountNumber(acc2);
			    if(isvalid1){
			    		System.out.println("Enter pin:");
			    		int pin2=sc.nextInt();
			    		boolean isvalid2=service.validatePin(pin2);
			    		if(isvalid2){
			    			System.out.println("Enter withdraw amount");
			    			long withdraw=sc.nextLong();
			    			Customer c=service.displayCustomer(acc2);
			    			long b=c.getBalance();
			    			long a=service.withDraw(c, withdraw);
			    			service.printTransaction(c);
			    			if(a<b){
			    				System.out.println("Successfully WithDrawn");
			    				System.out.println("Updated Balance:"+a);
			    			}else{
			    				System.out.println("Insufficient Balance");
			    			}
			    		}else{
			    			System.out.println("Please enter correct pin");
			    		}
			    }else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				break;
			case 5:
				System.out.println("Enter Account No.");
			    int acc3=sc.nextInt();
			    boolean isvalid2=service.validateAccountNumber(acc3);
			    if(isvalid2){
			    	    Customer cust3=service.displayCustomer(acc3);
			    		System.out.println("Enter pin:");
			    		int pin3=sc.nextInt();
			    		boolean isvalid3=service.validatePin(pin3);
			    		if(cust3.getAccountNo()==acc3&&cust3.getPin()==pin3){
			    			System.out.println("Enter the Account Number to transfer:");
			    			int acc4=sc.nextInt();
			    			boolean isvalid4=service.validateAccountNumber(acc4);
			    			if(isvalid4){
			    			System.out.println("Enter Name of the Receiver:");
			    			String sName=sc.next();
			    			System.out.println("Enter IFSC Code");
			    			int ifsc=sc.nextInt();
			    			System.out.println("Enter amount of transfer:");
			    			long deposit=sc.nextLong();
			    			if(cust3.getBalance()>deposit){
			    			long newBal=0;
			    			newBal=cust3.getBalance()-deposit;
			    			cust3.setBalance(newBal);
			    			service.printTransaction(cust3);
			    			Customer cust4=service.displayCustomer(acc4);
			    			long newBalance=cust4.getBalance()+deposit;
			    			cust4.setBalance(newBalance);
			    			service.printTransaction(cust4);
			    			System.out.println("Transaction Successful");
			    			System.out.println("Account No:"+acc3+"Amount after deduction:"+cust3.getBalance());
			    			System.out.println("Account No:"+acc4+"Amount after deduction:"+cust4.getBalance());
			    			}else {
								try {
									throw new CustomerNotFound("Insufficient Balance");
								} catch (CustomerNotFound e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
			    		}else {
							try {
								throw new CustomerNotFound("Please enter a valid Account Number");
							} catch (CustomerNotFound e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
			    }else {
					try {
						throw new CustomerNotFound("Please enter a valid pin");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			    }
			    		else {
					try {
						throw new CustomerNotFound("Please enter a valid Account Number");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				break;
			case 6:
				System.out.println("enter account no.");
				int acc6=sc.nextInt();
				System.out.println("enter pin");
				int pin6=sc.nextInt();
				Customer c3=service.printTransactions(acc6, pin6);
			case 7:

				System.exit(0);
				break;

			default:
				break;
			}
		}
	}
}
