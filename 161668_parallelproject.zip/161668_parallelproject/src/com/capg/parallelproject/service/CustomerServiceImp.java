package com.capg.parallelproject.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.dao.CustomerDAOImp;

public class CustomerServiceImp implements ICustomerService {
    CustomerDAOImp dao=new CustomerDAOImp();
	@Override
	public boolean createAccount(Customer c) {
		// TODO Auto-generated method stub
		  return dao.createAccount(c);
	}

	@Override
	public long showBalance(int cid,int pin) {
		// TODO Auto-generated method stub
		return dao.showBalance(cid,pin);
	}

	@Override
	public long deposit(Customer c, long deposit){
		// TODO Auto-generated method stub
		long newBal=0;
		newBal=c.getBalance()+deposit;
		c.setBalance(newBal);
		
		return dao.deposit(c,deposit);
	}

	@Override
	public long withDraw(Customer c, long amount) {
		// TODO Auto-generated method stub
		
		if(c.getBalance()>amount){
			long newBal=0;
			newBal=c.getBalance()-amount;
			c.setBalance(newBal);
			return dao.withDraw(c, amount);
			}
		return c.getBalance();
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,long amount, int acc1, int acc2, int pin1) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			if(b.getAccountNo()==acc2){
				if(c.getBalance()>amount){
					long bal=0;
					long bal1=0;
					bal=c.getBalance()-amount;
					bal1=b.getBalance()+amount;
					c.setBalance(bal);
					b.setBalance(bal1);
					flag=true;
				    return dao.fundTransfer(c,b,amount,acc1,acc2,pin1);
				}
			}
		}
		return flag;
	}

	@Override
	public Customer printTransactions(int cid,int pin) {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid, pin);
	}
	
	@Override
	public Customer printTransaction(Customer cid){
		return dao.printTransaction(cid);
	}
  /* public boolean validateCreateAccount(Customer c){
		
		// use regular expressions or our own user defined validations
		boolean flag=false;

		Pattern address = Pattern.compile("^[#.0-9 a-zA-Z,\\u0020-]+$");
		Pattern mobileNo=Pattern.compile("(0/91)?[7-9][0-9]{9}"); 
		//Pattern pincode=Pattern.compile("[0-9]{6}");
		Matcher mobileMatch=mobileNo.matcher(c.getMobileNo());
		Matcher mtch = address.matcher(c.getAddress());
		//Matcher pinMatch=pincode.matcher(c.getPinCode());
		if(c.getCustomerFirstName().length()>=3 && mtch.matches()&& mobileMatch.matches()&&(c.getAge()<=100||c.getAge()>0)&&pinMatch.matches()&& c.getAddress().equals("chennai")){
			
			flag=true;	
		}else if(c.getCustomerFirstName().length()<3){
			System.out.println("please enter valid name. Name should be atleast 3 characters");
			flag=false;
		}else if(c.getAge()<0||c.getAge()>100){
			System.out.println("Please enter valid age. Age should be a number ranging between 0 and 100");
			flag=false;
		}
		else if(!mtch.matches()){
			System.out.println("Please enter valid address");
			flag=false;
		}else if(!mobileMatch.matches()){
			System.out.println("Please enter valid mobile no.");
			flag=false;
		}else if(!pinMatch.matches()){
			System.out.println("Please enter valid pincode");
			flag=false;
		}
		return flag;
	}*/
	public  String toTitleCase(String givenString) {
	    String[] arr = givenString.split(" ");
	    StringBuffer sb = new StringBuffer();

	    for (int i = 0; i < arr.length; i++) {
	        sb.append(Character.toUpperCase(arr[i].charAt(0)))
	            .append(arr[i].substring(1)).append(" ");
	    }          
	    return sb.toString().trim();
	}  
	public boolean validateOpeningBalance(long openingBalance){
		
		boolean flag=true;
		if(openingBalance<=0){
			flag=false;
		}
		return flag;
	}
	public boolean validateAccountNumber(int cid) {
		// TODO Auto-generated method stub
		return dao.validateAccountNumber(cid);
	}
	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		return dao.validatePin(pin);
	}

	@Override
	public Customer displayCustomer(int accNo) {
		// TODO Auto-generated method stub
		return dao.displayCustomer(accNo);
	}

    public boolean validateCustomerFirstName(String customerFirstName){
    	boolean flag=false;
    	Pattern firstName=Pattern.compile("^[A-Za-z]{1,}\\s?[A-Za-z]{0,}$");
    	Matcher mtch = firstName.matcher(customerFirstName);
		if(customerFirstName.length()>=2&&mtch.matches()){
			flag=true;
		}
    return flag;
    }

	public boolean validateCustomerMiddleName(String customerMiddleName) {
		// TODO Auto-generated method stub
		boolean flag=false;
		Pattern middleName=Pattern.compile("[a-zA-z]\\s\\\\rne$");
    	Matcher mtch = middleName.matcher(customerMiddleName);
		if(mtch.matches()){
			flag=true;
		}
    return flag;
	}

	public boolean validateCustomerLastName(String customerLastName) {
		// TODO Auto-generated method stub
		boolean flag=false;
    	Pattern lastName=Pattern.compile("^[A-Za-z]{1,}\\s?[A-Za-z]{0,}$");
    	Matcher mtch = lastName.matcher(customerLastName);
		if(customerLastName.length()>=0&&mtch.matches()){
			flag=true;
		}
    return flag;
	}

	public boolean validateMobileNo(StringBuffer mobileNo, Customer cus) {
		// TODO Auto-generated method stub
		Pattern mobileNo1=Pattern.compile("^[+(0/91)-]?[7-9][0-9]{9}"); 
		Matcher mobileMatch=mobileNo1.matcher(cus.getMobileNo());
		return mobileMatch.matches();
	}

	public boolean validateAge(int age) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(age<=100||age>0){
		flag=true;	
		}
		return flag;
	}

	public boolean validateAddress(StringBuffer address, Customer cus) {
		// TODO Auto-generated method stub
		Pattern address1=Pattern.compile("^[#.0-9 a-zA-Z,\\u0020-]+$");
    	Matcher mtch = address1.matcher(cus.getAddress());
    return mtch.matches();
	}
	public boolean validatePinCode(Integer address) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if((address>99999&&address<1000000)){
			flag=true;
		}
    return flag;
	}

	public int validateGender(String gender) {
		// TODO Auto-generated method stub
		if(gender.equals("M")||(gender.equals("MALE"))){
			return 1;
		}else if(gender.matches("F")||gender.matches("FEMALE")){
			return 2;
		}
		return 0;
	}
	public boolean validateEmailAddress(String email) {
        Pattern p = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
        Matcher m = p.matcher(email);
        return m.matches();
 }

	public int validatePanNo(String panNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
        Matcher m = p.matcher(panNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}

	public int validateAadharNo(String aadharNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[0-9]{12}");
        Matcher m = p.matcher(aadharNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
    }

	public int validateVoterId(String voterId) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{3}[0-9]{7}");
        Matcher m = p.matcher(voterId);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}

	public int validatedrivingLicenseNo(String drivingLicenseNo) {
		// TODO Auto-generated method stub
		Pattern p = Pattern.compile("^[A-Z]{2}[0-9]{13}");
        Matcher m = p.matcher(drivingLicenseNo);
        if(m.matches()){
        	return 1;
        }
		return 0;
	}
}