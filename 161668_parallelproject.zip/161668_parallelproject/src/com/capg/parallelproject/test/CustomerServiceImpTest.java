package com.capg.parallelproject.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.parallelproject.bean.Customer;
import com.capg.parallelproject.service.CustomerServiceImp;

public class CustomerServiceImpTest extends CustomerServiceImp {

	Customer c=new Customer(null, null, null, null, null, null, null, 0, null, null, null);
	Customer b=new Customer(null, null, null, null, null, null, null, 0, null, null, null);
	CustomerServiceImp a=new CustomerServiceImp();
	
	@Test
	public void testCreateAccount() {
		assertNotNull(a.createAccount(c));
	}

	@Test
	public void testShowBalance() {
		assertEquals(c.getBalance(), a.showBalance(c.getAccountNo(), c.getPin()));
	}

	@Test
	public void testDeposit() {
		long deposit=c.getBalance();
		assertEquals(c.getBalance(), a.deposit(c, deposit));
	}

	@Test
	public void testWithDraw() {
		long withDraw=c.getBalance();
		assertEquals(c.getBalance(), a.withDraw(c, withDraw));
	}

	@Test
	public void testFundTransfer() {
		long amount=c.getBalance();
		assertNotNull(a.fundTransfer(c, b, amount, c.getAccountNo(), b.getAccountNo(), c.getPin()));
	}

	@Test
	public void testPrintTransaction() {
		assertNotNull(c);
	}

}
