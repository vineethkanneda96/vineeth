package com.capgi.parallelproject.exception;

public class CustomerNotFound extends Exception {
	private static final long serialVersionUID = 1L;
	
    private String status;
	
	public CustomerNotFound() {
		this.status="Unable to perform CRUD on table";
	}
	
	public CustomerNotFound(String status) {
		super(status);
	}
	
	public String getStatus() {
		return this.status;
	}

	@Override
	public String toString() {
		return "EmployeeException [status=" + status + "]";
	}
}
